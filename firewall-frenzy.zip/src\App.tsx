import React from 'react';
import { GameScene } from './scenes/GameScene';
import './App.css';

function App() {
  return (
    <div className="App">
      <GameScene />
    </div>
  );
}

export default App;
